
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <table id="example2" class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>Room</th>
        <th>floor</th>
        <th>image</th>
        <th>detail</th>
        <th>price</th>
        <th><a href="<?php echo e(route('getaddRoom')); ?>"><button class="btn btn-success">thêm</button></a></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($r->room_no); ?></td>
        <td><?php echo e($r->floor); ?></td>
        <td>
        <img src="<?php echo e(asset('storage/' . $r->image)); ?>" alt="" width="150" height="150">
        </td>
        <td><?php echo e($r->detail); ?></td>
        <td><?php echo e($r->price); ?></td>
        <td>
          <a href="<?php echo e(route('geteditRoom', $r->id)); ?>"><button class="btn btn-primary">sửa</button></a>
          <a href="<?php echo e(route('deleteRom', $r->id)); ?>"><button class="btn btn-danger">xoá</button></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\asm1\resources\views/rooms/listRoom.blade.php ENDPATH**/ ?>