
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <table id="example2" class="table table-bordered table-hover">
    <thead>
      <tr>
        <th>Name</th>
        <th>icon</th>
        <th><a href="<?php echo e(route('getCreateService')); ?>"><button class="btn btn-success">Thêm</button></a></th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($s->name); ?></td>
        <td> <img src="<?php echo e(asset('storage/' . $s->icon)); ?>" alt="" width="150" height="150"></td>
        <td>
          <a href="<?php echo e(route('getEditService', $s->id)); ?>"><button class="btn btn-success">sửa</button></a>
          <a href="<?php echo e(route('deleteService', $s->id)); ?>"><button class="btn btn-danger">xoá</button></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\asm1\resources\views/services/listService.blade.php ENDPATH**/ ?>