
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
     <form action="" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="container">
               <div class="">
                    <div class="form-group">
                         <label for="">Tên Service</label>
                         <input type="text" name="name" class="form-control">
                    </div>
                    <div class="form-group">
                         <label for="">icon</label>
                         <input type="file" name="uploadfile" class="form-control">
                    </div>
                    <div class="text-right">
                         <button type="submit" class="btn btn-primary">Lưu</button>
                         <a href="" class="btn btn-danger">Hủy</a>
                    </div>
               </div>
     </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php3\asm1\resources\views/services/addService.blade.php ENDPATH**/ ?>